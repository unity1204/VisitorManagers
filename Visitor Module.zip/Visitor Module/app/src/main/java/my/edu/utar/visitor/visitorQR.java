package my.edu.utar.visitor;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import androidmads.library.qrgenearator.QRGContents;
import androidmads.library.qrgenearator.QRGEncoder;

public class visitorQR extends AppCompatActivity {

    ImageView qrcode;
    TextView hint;

    QRGEncoder qrgEncoder;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visitor_qr);

        qrcode = findViewById(R.id.QRcode);
        hint = findViewById(R.id.Hint);

        WindowManager manager = (WindowManager) getSystemService(WINDOW_SERVICE);

        Display display = manager.getDefaultDisplay();

        Point point = new Point();
        display.getSize(point);

        int width = point.x;
        int height = point.y;

        int dimen = width < height ? width : height;

        dimen = dimen * 3/4;

        //get ID:hint(textView) value to generate QR
        qrgEncoder = new QRGEncoder(hint.getText().toString(),null, QRGContents.Type.TEXT,dimen);

        try{
            bitmap = qrgEncoder.getBitmap(0);
            qrcode.setImageBitmap(bitmap);

        }catch(Exception e){

            Toast.makeText(QR_Code.this,e.getMessage(), Toast.LENGTH_SHORT).show();
        }

    }
}