package my.edu.utar.visitor;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void addVisitor(View v){
        Intent intent = new Intent(this, addVisitor.class);
        startActivity(intent);
    }

    public void visitorQR(View v){
        Intent intent = new Intent(this, visitorQR.class);
        startActivity(intent);
    }
}


