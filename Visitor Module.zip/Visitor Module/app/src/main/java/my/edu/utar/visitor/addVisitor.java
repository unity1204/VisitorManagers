package my.edu.utar.visitor;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class addVisitor extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_visitor);

        final EditText etname = new EditText(this);
        final EditText etphone = new EditText(this);

        final TextView tvname = new TextView(this);
        final TextView tvphone = new TextView(this);

        Button button3 = new Button(this);
        button3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                tvname.setText(etname.getText().toString());
                tvphone.setText(etphone.getText().toString());

                Toast.makeText(getApplicationContext(),"New Visitor added!", Toast.LENGTH_LONG).show();
            }
        });
    }

}